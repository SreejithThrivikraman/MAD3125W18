package com.example.sree.poll;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ActivityFeedback extends AppCompatActivity implements View.OnClickListener

{
    Button btnSend;
    Button btnCancel;
    EditText edit_tittle,edit_feedback;
    public String tittle,feedback;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);


        btnSend = (Button) findViewById(R.id.button_send);
        btnSend.setOnClickListener(this);

        btnCancel = (Button) findViewById(R.id.button_cancel);
        btnCancel.setOnClickListener(this);

        edit_tittle = findViewById(R.id.editText_feedback_tittle);
        edit_feedback = findViewById(R.id.editText_feedback);


    }

    @Override
    public void onClick(View v)

    {
        if (v.getId() == btnSend.getId())           // send mail
        {
            tittle = edit_tittle.getText().toString();
            feedback = edit_feedback.getText().toString();
            sendEmail();


        }
        else if (v.getId() == btnCancel.getId())
        {
            Intent home_launch = new Intent(getApplicationContext(),HomeActivity.class);
            startActivity(home_launch);
        }

    }

    public void sendEmail(){
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("text/plain");

        emailIntent.putExtra(Intent.EXTRA_EMAIL,
                new String[]{"someone@xyz.com"});

        emailIntent.putExtra(Intent.EXTRA_SUBJECT,
                tittle);
        emailIntent.putExtra(Intent.EXTRA_TEXT,
                feedback);

        emailIntent.setType("message/rfc822");

        startActivity(Intent.createChooser(emailIntent,
                "Select Email Client"));
    }
}
