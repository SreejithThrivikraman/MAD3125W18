package com.example.sree.poll;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    public Integer flag_item;
    DBHelper dbHelper;
    SQLiteDatabase PollDB;
    String Poll_tittle,Poll_question,Poll_option1,Poll_option2,Poll_option3,Poll_option4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                makeCall();
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_tim)
        {
           flag_item = 0;
            load_activity("0");


        }
        else if (id == R.id.nav_technology)
        {
            flag_item = 1;
            load_activity("1");
        }
        else if (id == R.id.nav_politics)
        {
            flag_item = 2;
            load_activity("2");
        }
        else if (id == R.id.nav_feedback)
        {

           Intent feedback_screen = new Intent(getApplicationContext(),ActivityFeedback.class);
           startActivity(feedback_screen);
        }
        else if (id == R.id.nav_exit)
        {
            finishAffinity();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }



    public void load_activity(String item)
    {
        Intent polling_page = new Intent(getApplicationContext(),Poll.class);


        switch (item)
        {
            case "0" :        {
                                //load_Tim();
                                polling_page.putExtra("option", "0");
                                startActivity(polling_page);
                                break;
                            }

            case "1" :         {
                                //load_Tech();
                                polling_page.putExtra("option", "1");
                                startActivity(polling_page);
                                break;
                            }

            case "2" :
                            {  // load_Politics();
                                polling_page.putExtra("option", "2");
                                startActivity(polling_page);
                                break;

                            }

                            default: {
                                System.err.println("Error in switch case .");

                                     }
        }




    }


    public void makeCall(){
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:4379986008"));

        if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.CALL_PHONE) !=
                PackageManager.PERMISSION_GRANTED)
        {
            Toast.makeText(getApplicationContext(),
                    "Call permission denied",Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(callIntent);
    }



    private void displayData(){

        try{
            PollDB = dbHelper.getReadableDatabase();

            String columns[] = {"Id","PollTitle","Question","Option1","Option2","Option3","Option4"
                    };

            Cursor cursor = PollDB.query(dbHelper.TB_NAME_POLL
                    ,columns,null,null,
                    null,null,null);

            while (cursor.moveToNext()){
                 Poll_tittle = cursor.getString
                        (cursor.getColumnIndex("PollTitle"));
                 Poll_question = cursor.getString(
                        cursor.getColumnIndex("Question")
                );

                 Poll_option1 = cursor.getString(
                        cursor.getColumnIndex("Option1")
                );

                Poll_option2 = cursor.getString(
                        cursor.getColumnIndex("Option2")
                );

                 Poll_option3 = cursor.getString(
                        cursor.getColumnIndex("Option3")
                );

                Poll_option4 = cursor.getString(
                        cursor.getColumnIndex("Option4")
                );



                Toast.makeText(this,"" +this.Poll_tittle+this.Poll_question+Poll_option1+Poll_option2+Poll_option3+Poll_option4,
                        Toast.LENGTH_LONG).show();

            }


        }catch (Exception e){
            Log.e("RegisterActivity : ",
                    "Unable to fetch the records");
        }

        PollDB.close();

    }

    public void load_Tim()
    {



        displayData();


    }

    public void load_Tech()
    {

    }

    public void load_Politics()
    {

    }

}
