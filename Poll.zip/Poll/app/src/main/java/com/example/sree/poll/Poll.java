package com.example.sree.poll;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;

import org.w3c.dom.Text;

public class Poll extends AppCompatActivity implements View.OnClickListener{

    TextView learn_more1,learn_more_2,learn_more_3,learn_more_4;
    RadioButton radio_1,radio_2,radio_3,radio_4;
    String new_option = "";
    Poll()
    {

    }


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_poll);

        Bundle bundle = getIntent().getExtras();
        String message = bundle.getString("option");



        learn_more1 = findViewById(R.id.learn_more_1);
        learn_more1.setOnClickListener(this);

        learn_more_2 = findViewById(R.id.learn_more_2);
        learn_more_2.setOnClickListener(this);

        learn_more_3 = findViewById(R.id.learn_more_3);
        learn_more_3.setOnClickListener(this);

        learn_more_4 = findViewById(R.id.learn_more_4);
        learn_more_4.setOnClickListener(this);

        radio_1= findViewById(R.id.radio_option_1);
        radio_2= findViewById(R.id.radio_option_2);
        radio_3= findViewById(R.id.radio_option_3);
        radio_4= findViewById(R.id.radio_option_4);




        switch (message)
        {
            case "0" : {
                radio_1.setText("Coffee");
                radio_2.setText("Donut");
                radio_3.setText("Beagel");
                radio_4.setText("Timbit");
                new_option = "0";

                break;
            }

            case "1" : {
                radio_1.setText("Toronto");
                radio_2.setText("ottawa");
                radio_3.setText("Montreal");
                radio_4.setText("Vancouver");
                new_option = "1";
                break;
            }

            case "2" : {
                radio_1.setText("Justine Trudeau");
                radio_2.setText("John Abbott");
                radio_3.setText("Kim Campbell");
                radio_4.setText("Charles Tupper");
                new_option = "2";
                break;

            }

        }



    }


    @Override
    public void onClick(View v)
    {

        if (v.getId() == learn_more1.getId())           // send mail
        {
            String option = "";

            Intent website = new Intent(getApplicationContext(),web.class);
            if(new_option.equals("0"))
            {
                 option = "1";
            }
            else if (new_option.equals("1"))
            {
                 option = "5";
            }
            else if(new_option.equals("2"))
            {
                 option = "9";
            }



            website.putExtra("option", option);
            startActivity(website);


        }


        if (v.getId() == learn_more_2.getId())           // send mail
        {


            String option = "";

            Intent website = new Intent(getApplicationContext(),web.class);
            if(new_option.equals("0"))
            {
                option = "2";
            }
            else if (new_option.equals("1"))
            {
                option = "6";
            }
            else if(new_option.equals("2"))
            {
                option = "10";
            }
            website.putExtra("option", option);
            startActivity(website);


        }

        if (v.getId() == learn_more_3.getId())           // send mail
        {


            Intent website = new Intent(getApplicationContext(),web.class);
            String option = "2";
            website.putExtra("option", option);
            startActivity(website);


        }

        if (v.getId() == learn_more_4.getId())           // send mail
        {


            Intent website = new Intent(getApplicationContext(),web.class);
            String option = "3";
            website.putExtra("option", option);
            startActivity(website);


        }

    }
}
