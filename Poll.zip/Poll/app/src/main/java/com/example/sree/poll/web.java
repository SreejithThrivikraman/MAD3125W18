package com.example.sree.poll;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class web extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);

        Bundle bundle = getIntent().getExtras();
        String message = bundle.getString("option");
        String url = "";

        switch (message)
        {
            case "1" : {
                        url = "https://www.google.ca/search?q=coffee&oq=coffee&aqs=chrome..69i57j0l5.940j0j4&sourceid=chrome&ie=UTF-8";
                        break;
                       }

            case "2" : {
                url = "https://www.google.ca/search?q=donut&oq=donut&aqs=chrome..69i57j0l5.719j0j4&sourceid=chrome&ie=UTF-8";
                break;
            }

            case "3" :
                {
                url = "https://www.google.ca/search?ei=AIjPWta5KajojwT2_7fQDQ&q=bagel&oq=bagel&gs_l=psy-ab.3..0i67k1l8j0j0i20i263k1.5332.5766.0.5925.5.4.0.1.1.0.135.424.1j3.4.0....0...1c.1.64.psy-ab..0.5.426...35i39k1j0i3k1.0._w3paxZEs9o";
                break;
            }


            case "4" :
            {
                url = "http://www.timhortons.com/ca/en/menu/timbits.php";
                break;
            }


            case "5" : {
                        url = "https://www.toronto.ca/";
                        break;
                       }

            case "9" : {
                        url = "https://en.wikipedia.org/wiki/Justin_Trudeau";
                        break;
                       }



        }

        WebView webManual = (WebView) findViewById(R.id.webpage);
        webManual.loadUrl(url);

    }
}
