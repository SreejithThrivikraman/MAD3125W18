package com.example.sree.poll;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class Splash extends AppCompatActivity {
    DBHelper dbHelper;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);


        final Context context;
        context = this;

        Thread timer = new Thread(){
            public void run(){
                try{
                    sleep(3000);
                }catch (Exception ex){
                    Log.e("Launcher","Thread wait failed");
                }
                finally {
                    finish();
                    Intent loginIntent = new Intent(context,HomeActivity.class);
                    startActivity(loginIntent);
                }
            }
        };

        timer.start();
        dbHelper = new DBHelper(getApplicationContext());
        Toast.makeText(getApplicationContext(),"Database created successfully !!!",Toast.LENGTH_LONG).show();



    }



    // inserting data into database.

    public void insertData(){

        SQLiteDatabase pollDB = dbHelper.getWritableDatabase();

        String pollTitles[] = {"Tim","Technology","Politics"};
        String questions[] = {"What is the best thing about Tim?",
                "Which is the IT hub of Canada?",
                "Who is the most famous prime minister?"};
        String options[][] = {{"Coffee", "Donuts", "Bagels", "Timbits"},
                {"Toronto", "Ottawa", "Montreal", "Vancouver"},
                {"Justine Trudeau","John Abbott", "Kim Campbell", "Charles Tupper"}};
        int countOptions[][] = {{0,0,0,0},{0,0,0,0},{0,0,0,0}};

        for(int i=0; i<pollTitles.length; i++) {

            ContentValues cv = new ContentValues();
            cv.put("PollTitle", pollTitles[i]);
            cv.put("Question", questions[i]);

            for(int j=0;j<4;j++) {
                cv.put("Option"+(j+1), options[i][j]);
                cv.put("CountOption"+(j+1), countOptions[i][j]);
            }

            try {
                pollDB = dbHelper.getWritableDatabase();
                pollDB.insert("Poll",null, cv);
                Log.v("Insert record", "Record inserted successfully");
            } catch (Exception e) {
                Log.e("Insert Record Error", e.getMessage());
            }
        }
        pollDB.close();
    }
}
