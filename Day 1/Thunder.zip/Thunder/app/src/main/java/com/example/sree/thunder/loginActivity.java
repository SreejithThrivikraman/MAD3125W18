package com.example.sree.thunder;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class loginActivity extends AppCompatActivity implements View.OnClickListener   // view on clickListner is for the clickable event.
{

    Button btnLogin,regButton;
    EditText edit_uname,edit_pass;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnLogin = (Button) findViewById(R.id.button);
        regButton = (Button) findViewById(R.id.button2);

        edit_uname = (EditText)findViewById(R.id.editText);
        edit_pass = (EditText)findViewById(R.id.editText1);


        btnLogin.setOnClickListener(this);

    }

    @Override
    public void onClick(View v)

    {
          if(v.getId() == btnLogin.getId())
          {
             // Toast.makeText(this,"Login clicked",Toast.LENGTH_LONG).show();

              String uname = edit_uname.getText().toString();
              String upass = edit_pass.getText().toString();


              Toast.makeText(this,"User Name :" + uname + "Password :" + upass,Toast.LENGTH_LONG).show();
          }


    }
}
